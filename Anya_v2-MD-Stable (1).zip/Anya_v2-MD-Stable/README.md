<p align="center">
    <img src="https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png">
</p>

<h1 align="center">Anya_v2 - MultiDevice</h1>

<p align="center">
  <a href="https://github.com/PikaBotz"><img src="http://readme-typing-svg.herokuapp.com?color=FFFFFF&center=true&vCenter=true&multiline=false&lines=Queen+Anya+v2+MultiDevice;New+Plugin+Base+Modification;Developed+by+Pika~Kun;Give+star+and+forks+this+Repo+🌟" alt="AnyaReadme"></a>
</p>

<p align="center">
    <a href="#"><img title="Anya_v2-MD" src="https://img.shields.io/badge/WhatsApp%20BOT-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>

<p align="center">
    <a href="https://github.com/PikaBotz"><img title="Author" src="https://img.shields.io/badge/AUTHOR-PikaBotz-green.svg?style=for-the-badge&logo=github"></a>
</p>

---

## **IMPORTANT**

> **Warning**: This script is not for trading without permission.

---

## Table of Contents
- [Tap Here For Help ⛩️](#tap-here-for-help-️)
- [Scan QR Here](https://anya-qr-teamolduser.koyeb.app/)
- [Deploy On Railway](#deploy-on-railway)
- [Deploy On Replit](#deploy-on-replit)
- [Deploy On Heroku](#deploy-on-heroku)
- [Terms & Conditions](#terms--conditions)
- [Thanks to ✨](#thanks-to-)
---

## Tap Here For Help ⛩️

- [Contact me on WhatsApp Messenger 🎐](https://wa.me/918811074852?text=Hello%20Pika~Kun%20sir...%20I%20need%20some%20help%20in%20Anya%20v2)

- My email address: [alammdarif07@gmail.com](mailto:alammdarif07@gmail.com) 🎐

---

## Scan QR Here

<a href="https://anya-qr-teamolduser.koyeb.app/"><img src="./AnyaPikaMedia/HomeScreen/AnyaQRscan.png" align="center" width="90" /> </a>

---

## Deploy On Railway

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app)

---

## Deploy On Replit

[![Run on Repl.it](https://repl.it/badge/github/PikaBotz/Anya_v2-MD)](https://repl.it/github/PikaBotz/Anya_v2-MD)

---

## Deploy On Heroku

[Deploy on Heroku](https://heroku.deploy.queenanya.work.gd/)

---

## Terms & Conditions
1. This repository is not for sale or trade.
2. Don't forget to give this repository a ⭐️ star.
3. This script is not made for illegal purposes.
4. If you have a problem, [contact me](https://wa.me/918811074852?text=Hello%20*master%20Pika~Kun*%20sir...%20I%20need%20some%20help%20in%20Anya%20v2...%20🥲) for help.

---

## Thanks to ✨
- [OldUser](https://github.com/Teamolduser) - ✅ For web and modules compatibility
- [AdirajShing](https://github.com/adiwajshing/Baileys) - ✅ For a huge library
